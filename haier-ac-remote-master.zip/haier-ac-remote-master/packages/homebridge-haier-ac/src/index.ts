// eslint-disable-next-line import/no-default-export
export { haierAcPlugin as default } from './haier';
